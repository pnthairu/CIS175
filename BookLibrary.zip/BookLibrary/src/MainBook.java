import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import controller.BookHelper;
import model.BookClass;


public class MainBook {
	
	static Scanner in = new Scanner(System.in);
	static BookHelper lih = new BookHelper();

	// method to add new store and item into the database
	private static void addAnItem() {
		
		// user input for store name			
		String firstName = "";
		String secondName = "";
		String authorFullName = "";
		authorFullName =  firstName + " " + secondName;
		// user input for item name
		System.out.print("Please enter author name: ");
		authorFullName = in.nextLine();
		
		System.out.print("Please enter the book Title: ");			
		String title = in.nextLine();
		
		// user input for Book name
		System.out.print("Please enter the book ISBN: ");			
		String sbno = " ";
		sbno = in.nextLine();

		// adding store and item to the list
		BookClass toAdd = new BookClass(sbno, authorFullName, title);
		lih.insertBook(toAdd);
	}

	public static void main(String[] args) {
		runMenu();		
	}
	
	public static void runMenu() {
		boolean goAgain = true;
		System.out.println("----------------------------------");
		System.out.println("     Paul Thairu Book Store       ");
		System.out.println("----------------------------------");
		while (goAgain) {
			System.out.println("Please choose from the options below");
			System.out.println("    1. Add new Book");
			System.out.println("    2. Edit exiting Book ");
			System.out.println("    3. DELECT Books");
			System.out.println("    4. View all Books ");
			System.out.println("    5. EXIT ");
			System.out.println("----------------------------------");
			System.out.print("          Your selection: \n");
			System.out.println("----------------------------------");
			int selection = in.nextInt();
			in.nextLine();

			if (selection == 1) {
				addAnItem();
			} else if (selection == 4) {
				viewTheList();			
			} else {
				lih.cleanUp();
				System.out.println("   Goodbye!   ");
				goAgain = false;
			}
		}
	}
		
	private static void viewTheList() {
			List<BookClass> allBooks = lih.displayAllBook();
			for(BookClass singleItem : allBooks){
				System.out.println(singleItem.returnItemDetails());
		}	
	}
}
