package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="library.books")

public class BookClass{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	
	@Column(name="AUTHOR")
	private String bookAuthor;
	
	@Column(name="TITLE")
	private String bookTitle;
	
	@Column(name="ISBN")
	private String isbn;
	
	
	public BookClass() {
		super();
	}
	
	public BookClass(String author, String title, String isbn) {		
		this.bookAuthor = author;
		this.bookTitle = title;
		this.isbn = isbn;
		
	}


	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String returnItemDetails() {		
		return isbn + " " + bookAuthor + " " + bookTitle;
	}

	@Override
	public String toString() {		
		return "BookClass [ISBN=" + isbn + ", bookAuthor=" + bookAuthor + ", bookTitle=" + bookTitle + "]";
	}
	
	
}
