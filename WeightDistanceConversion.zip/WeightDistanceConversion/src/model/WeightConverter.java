package model;

public class WeightConverter {
	
	// Weight class variables
	private int tonnes;
	private int pounds;
	private int ounces;
	private int kilograms;
	private int grams;
	private int stones;
	
	//Default constructor with no arguments
	public WeightConverter() {
		super();		
	}
	
	// Weight constructor with one argument
	public WeightConverter(int tonnes) {
		super();	
		this.tonnes = tonnes;
		setWeight(tonnes); // using calling setDistance method to do the conversion based on tonnes entered by the user
	}

	// Getter method for tonnes
	public int getTonnes() {
		return tonnes;
	}

	// Setter method for tonnes
	public void setTonnes(int tonnes) {
		this.tonnes = tonnes;		
		setWeight(tonnes);
	}

	// Getter method for pounds
	public int getPounds() {
		return pounds;
	}

	//Setter method for pounds
	public void setPounds(int pounds) {
		this.pounds = pounds;
	}

	// Getter method for ounces
	public int getOunces() {
		return ounces;
	}

	//Setter method for ounces
	public void setOunces(int ounces) {
		this.ounces = ounces;
	}

	// Getter method for kilograms
	public int getKilograms() {
		return kilograms;
	}

	//Setter method for kilograms
	public void setKilograms(int kilograms) {
		this.kilograms = kilograms;
	}

	//Getter method for grams
	public int getGrams() {
		return grams;
	}

	// Setter method for grams
	public void setGrams(int grams) {
		this.grams = grams;
	}

	//Getter method for stones
	public int getStones() {
		return stones;
	}

	//Setter method for stones
	public void setStones(int stones) {
		this.stones = stones;
	}
	
	// Method to do the conversion from tonnes to others
	public void setWeight(int tonnes) {
		
		final int POUNDS = 2204;
		final int OUNCES = 35273;
		final int KILOGRAMS = 1000;
		final int GRAMS = 1000000;
		final int STONES = 	157;
		
		int tonnesLeft;	
		
		setPounds (tonnes * POUNDS);			
		setOunces (tonnes * OUNCES);		
		setKilograms (tonnes * KILOGRAMS);		
		setGrams (tonnes * GRAMS);		
		setStones (tonnes * STONES);		
	}

	@Override
	public String toString() {
		return "WeightConverter [tonnes=" + tonnes + ", pounds=" + pounds + ", ounces=" + ounces + ", kilograms="
				+ kilograms + ", grams=" + grams + ", stones=" + stones + "]";
	}
	
	
	

}
