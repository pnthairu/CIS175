package model;

public class DistanceConverter {
	
	// Declaring variables
	private double miles;
	private double kilometers;
	private double meters;
	private double centimeters;
	
	// Default constructor with no arguments
	public DistanceConverter() {
		super();		
	}
	
	// Constructor with one argument
	public DistanceConverter(double miles) {
		super();	
		this.miles = miles;
		setDistance(miles); // using calling setDistance method to do the conversion based on miles entered by the user
	}

	// Getter method for miles
	public double getMiles() {
		return miles;
	}

	// Setter method for miles
	public void setMiles(double miles) {
		this.miles = miles;
	}

	// Getter method for kilometers
	public double getKilometers() {
		return kilometers;
	}

	// Setter method for Kilometers
	public void setKilometers(double kilometers) {
		this.kilometers = kilometers;
	}
	
	//Getter method for meters
	public double getMeters() {
		return meters;
	}

	// Setter method for meters
	public void setMeters(double meters) {
		this.meters = meters;
	}

	// Getter method for centimeters
	public double getCentimeters() {
		return centimeters;
	}

	// Setter method for centimeters
	public void setCentimeters(double centimeters) {
		this.centimeters = centimeters;
	}
	
	// Method to convert miles to km, m and cm
	public void setDistance(double miles) {
		
		final double KM = 1.6;
		final double METERS = 1609.34;
		final double CM = 160934;
		
		double milesLeft;
		
		setKilometers (miles * KM);			
		setMeters (miles * METERS);				
		setCentimeters (miles * CM);		
		
	}

	@Override
	public String toString() {
		return "DistanceConverter [miles=" + miles + ", kilometers=" + kilometers + ", meters=" + meters + ", centimeters="
			+ centimeters + "]";
	}

	
	
	

}
