package dmacc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeContactsApplicationTests {

	@Test
	void contextLoads() {
	}

}
